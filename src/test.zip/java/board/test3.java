package board;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.pdfbox.contentstream.operator.Operator;
import org.apache.pdfbox.cos.COSArray;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.cos.COSString;
import org.apache.pdfbox.pdfparser.PDFStreamParser;
import org.apache.pdfbox.pdfwriter.ContentStreamWriter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDStream;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;
import org.fit.pdfdom.PDFDomTree;

public class test3 {
	private static final Pattern TOKEN_PATTERN = Pattern.compile("[0-9a-f]{64}+|[0-9A-F]{40}+");

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		substituteTokens();
	}
	
	private static void substituteTokens() {
		
		Map<String, String> map = new HashMap<>();
	    map.put("김태훈", "Kim Tae Hoon");
	    map.put("test", "테스트");
		
	    /*PDDocument document = null;
		try {
			document = PDDocument.load(new File("E:/input.pdf"));
		} catch (InvalidPasswordException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		PDAcroForm pDAcroForm = document.getDocumentCatalog().getAcroForm();
		if( pDAcroForm != null ){
		    List<PDField> fields = pDAcroForm.getFields();
		    for (PDField field : fields) {
		        for (Map.Entry<String, String> entry : map.entrySet()) {
		            if (entry.getKey().equals(field.getFullyQualifiedName())) {
		                try {
							field.setValue(entry.getValue());
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
		                field.setReadOnly(true);
		            }
		        }
		    }
		}
	    File out = new File("E:/output.pdf");
	    try {
			document.save(out);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    try {
			document.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
	    PDDocument document = null;
		try{
			/*try {
				document = PDDocument.load(new File("E:/input.pdf"));
				
			    Writer output = new PrintWriter("E:/pdf.html", "utf-8");
			    try {
					new PDFDomTree().writeText(document, output);
				} catch (ParserConfigurationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			     
			    output.close();
				
			} catch (InvalidPasswordException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (document.isEncrypted()) {
				//throw new IOException("Error: Encrypted documents are not supported for this example.");
			}*/
			
			try {
				document = PDDocument.load(new File("E:/test.pdf"));
			} catch (InvalidPasswordException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			for (PDPage page : document.getPages()) {
				PDFStreamParser parser = null;
				try {
					parser = new PDFStreamParser(page);
					parser.parse();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				List<Object>tokens = parser.getTokens();
				List<Object>newTokens = new ArrayList<Object>();
				for (Object token : tokens) {
					if (token instanceof Operator) {
						Operator op = (Operator) token;
						//System.out.println(op.getName());
						if (op.getName().equals("Tj")) {
							Object argumentToken = newTokens.get(newTokens.size() - 1);
							if (argumentToken instanceof COSString) {
								COSString stringToken = (COSString) argumentToken;
								System.out.println(stringToken.getString());
								Collection<String> tokenStrings = null;
								try {
									tokenStrings = collectTokens(stringToken.getString());
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								//if (!tokenStrings.isEmpty()) {
									String detokenizedString = substituteTokens(stringToken.getString(),
											tokenStrings, "static replacement");
									
									for (Map.Entry<String, String> entry : map.entrySet()) {
							            if (entry.getKey().equals(stringToken.getString())) {
							            	detokenizedString = entry.getValue();
							            }
							        }
									
									if (detokenizedString != null) {
										stringToken.setValue(detokenizedString.getBytes());
									}
								//}
							}
						}else if (op.getName().equals("TJ")) {	
							String text = "";
							Object argumentToken = newTokens.get(newTokens.size() - 1);
							if (argumentToken instanceof COSString || argumentToken instanceof COSArray) {
								COSArray previous = (COSArray) newTokens.get(newTokens.size() - 1);
			                    for (int k = 0; k < previous.size(); k++) {
			                        Object arrElement = previous.getObject(k);
			                        if (arrElement instanceof COSString) {
			                            COSString cosString = (COSString) arrElement;
			                            String string = "";
										try {
											string = cosString.getString();
										} catch (Exception e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
			                            text += string;
			                        }
			                    }
								try {
									System.out.println(text);
								} catch (Exception e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								Collection<String> tokenStrings = null;
								try {
									tokenStrings = collectTokens(text);
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								//if (!tokenStrings.isEmpty()) {
									String detokenizedString = substituteTokens(text,
											tokenStrings, "static replacement");
									
									for (Map.Entry<String, String> entry : map.entrySet()) {
							            if (entry.getKey().equals(text)) {
							            	detokenizedString = entry.getValue();
							            }
							        }
									
									if (detokenizedString != null) {
										previous.setString(0, detokenizedString);
									}
								//}
							}
						}
					}
					newTokens.add(token);
				}
				PDStream newContents = new PDStream(document);
				OutputStream out = null;
				try {
					out = newContents.createOutputStream(COSName.FLATE_DECODE);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				ContentStreamWriter writer = new ContentStreamWriter(out);
				try {
					writer.writeTokens(newTokens);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				page.setContents(newContents);
			}
			FileOutputStream fileOutputStream = null;
			try {
				fileOutputStream = new FileOutputStream(new File("E:/output.pdf"));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				document.save(fileOutputStream);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} finally {
			if (document != null) {
				try {
					document.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	public static Collection<String> collectTokens(String tokenizedText) throws IOException {
		Set<String> tokens = new HashSet<>();
		Matcher matcher = TOKEN_PATTERN.matcher(tokenizedText);
		while (matcher.find()) {
			tokens.add(matcher.group());
		}
		return tokens;
	}
	
	public static String substituteTokens(String text, Collection<String> tokens, String staticReplacementText) {
		String result = text;
		System.out.println(result);
		for (String token : tokens) {
			result = result.replace(token, staticReplacementText);
		}
		return result;
	}

}
