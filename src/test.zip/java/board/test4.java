package board;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PRStream;
import com.itextpdf.text.pdf.PdfDictionary;
import com.itextpdf.text.pdf.PdfDocument;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfObject;
import com.itextpdf.text.pdf.PdfPage;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfStream;
import com.itextpdf.text.pdf.PdfWriter;

public class test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test();
	}
	
	public static void test() {
		String src = "E:/test.pdf";
		String dest = "E:/output.pdf";
		
		Map<String, String> map = new HashMap<>();
	    map.put("김태훈", "Kim Tae Hoon");	
	    map.put("test", "테스트");
    	

		/*PdfDocument pdfDoc = new PdfDocument(new PdfReader(SRC), new PdfWriter(DEST));
		
	    int noOfPages = pdfDoc.getNumberOfPages();
	    for (int i = 1; i < noOfPages; i++) {
	        PdfPage page = pdfDoc.getPage(i);
	        PdfDictionary dict = page.getPdfObject();
	        PdfObject object = dict.get(PdfName.Contents);
	        if (object instanceof PdfStream) {
	            PdfStream stream = (PdfStream) object;
	            byte[] data = stream.getBytes();
	            stream.setData(new String(data).replace("Hello", "Hi").getBytes("UTF-8"));
	        }
	    }
	    pdfDoc.close();*/
		
		PdfReader reader = null;
		try {
			reader = new PdfReader(src);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    PdfDictionary dict = reader.getPageN(1);
	    PdfObject object = dict.getDirectObject(PdfName.CONTENTS);
	    if (object instanceof PRStream) {
	        PRStream stream = (PRStream) object;
	        byte[] data = null;
			try {
				data = PdfReader.getStreamBytes(stream);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	        String string = new String(data);
	        System.out.println("string:"+string);
	        

	        for (Map.Entry<String, String> entry : map.entrySet()) {
	            //if( string.contains(entry.getKey()) ){
	    			string = string.replace(entry.getKey(), entry.getValue());
	    		//}
	        }

	        //String eredeti = "öűóá";
	        //final String s = new String(eredeti.getBytes());

	        //stream.setData(new String(data).replace("Hello World", s).getBytes("ISO-8859-2"));
	        
	        try {
				stream.setData(string.getBytes());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    PdfStamper stamper = null;
		try {
			stamper = new PdfStamper(reader, new FileOutputStream(dest));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    try {
			stamper.close();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    //Paragraph preface = new Paragraph();
	    //preface.setAlignment(Element.ALIGN_CENTER);

	    reader.close();
	}

}
