package board;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import org.apache.poi.extractor.POIOLE2TextExtractor;
import org.apache.poi.extractor.POITextExtractor;
import org.apache.poi.hslf.extractor.PowerPointExtractor;
import org.apache.poi.hssf.extractor.ExcelExtractor;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.ooxml.extractor.ExtractorFactory;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.xslf.extractor.XSLFPowerPointExtractor;
import org.apache.poi.xssf.extractor.XSSFExcelExtractor;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;

public class test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String path = "E:\\개인\\이력서\\2018_Interpark_Recruit(김태훈).docx";
		path = "E:\\개인\\이력서\\김태훈개인이력카드.doc";
		System.out.println("path:"+path);
		test1(path);
		
		System.out.println("=====complete=====");
	}
	
	@SuppressWarnings("deprecation")
	private static void test1(String path){
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(path);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		POIFSFileSystem fileSystem = null;
		try {
			fileSystem = new POIFSFileSystem(fis);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			test2(path);
		}
		
		// Firstly, get an extractor for the Workbook
		POITextExtractor oleTextExtractor = null;
		try {
			oleTextExtractor = ExtractorFactory.createExtractor(fileSystem);
			

		   if (oleTextExtractor instanceof ExcelExtractor) {
				ExcelExtractor ex = new ExcelExtractor(fileSystem);
	            ex.setFormulasNotResults(true);
	            ex.setIncludeSheetNames(true);
	            System.out.println("ExcelExtractor: " + ex.getText());
		   }
		   // A Word Document
		   else if (oleTextExtractor instanceof WordExtractor ) {
			   WordExtractor we = new WordExtractor(fileSystem); 
			   System.out.println("WordExtractor: " + we.getText());
		   }
		   // PowerPoint Presentation.
		   else if (oleTextExtractor instanceof PowerPointExtractor) {
		      PowerPointExtractor powerPointExtractor = new PowerPointExtractor(fileSystem);
		      System.out.println("powerPointExtractor: " + powerPointExtractor.getText());
		   }

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	private static void test2(String path){
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(path);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		OPCPackage d = null;
		try {
			d = OPCPackage.open(fis);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		
		// Firstly, get an extractor for the Workbook
		POITextExtractor oleTextExtractor = null;
		try {
			oleTextExtractor = ExtractorFactory.createExtractor(d);			

		   if (oleTextExtractor instanceof XWPFWordExtractor) {
			   
               XWPFWordExtractor xw = new XWPFWordExtractor(d);
               System.out.println("XWPFWordExtractor: " + xw.getText());
           }else if (oleTextExtractor instanceof XSLFPowerPointExtractor ) {
               XSLFPowerPointExtractor xp = new XSLFPowerPointExtractor(d);
               System.out.println("XSLFPowerPointExtractor: " + xp.getText());
           }else if (oleTextExtractor instanceof XSSFExcelExtractor ) {
               XSSFExcelExtractor xe = new XSSFExcelExtractor(d);
               xe.setFormulasNotResults(true);
               xe.setIncludeSheetNames(true);
               System.out.println("XSSFExcelExtractor: " + xe.getText());
           }

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
