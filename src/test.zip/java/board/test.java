package board;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.xwpf.usermodel.Document;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.xmlbeans.XmlException;

//import com.independentsoft.office.word.Run;
//import com.independentsoft.office.word.Text;
//import com.independentsoft.office.word.WordDocument;

import org.apache.poi.extractor.POIOLE2TextExtractor;
import org.apache.poi.extractor.POITextExtractor;
import org.apache.poi.hslf.extractor.PowerPointExtractor;
import org.apache.poi.hssf.extractor.ExcelExtractor;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.ooxml.POIXMLDocumentPart;
import org.apache.poi.ooxml.extractor.ExtractorFactory;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String path = "E:\\개인\\이력서\\2018_Interpark_Recruit(김태훈).docx";
		path = "E:\\김태훈이력서.pptx";
		System.out.println("path:"+path);
		//test1(path);
		//test2(path);
		//test3(path);
		
		System.out.println("=====complete=====");
	}

	private static void test1(String path){
		InputStream in = null;
		try {
			in = new FileInputStream(new File(path));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        XWPFDocument document = null;
		try {
			try {
				//document = new XWPFDocument( Data.class.getResourceAsStream( path ) );

				document = new XWPFDocument(OPCPackage.open(in));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


        //XHTMLOptions options = XHTMLOptions.create().URIResolver(new FileURIResolver(new File(path)));

        OutputStream out = new ByteArrayOutputStream();


        try {
			//XHTMLConverter.getInstance().convert(document, out, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        String html=out.toString();
        System.out.println(html);
	}
	
	private static void test2(String path) {

	    String filepath = path;
	    String outpath = path.substring(0, path.indexOf("."))+"_target."+path.substring(0, path.indexOf("."));
	    //outpath = path.substring(0, path.indexOf("."))+"_target.doc";

	    try {

//	         WordDocument doc = new WordDocument(filepath);
//	    	 //Presentation presentation = new Presentation();
//	         
//	         /*List list = doc.getRuns();
//	         for(int i=0; i<list.size(); i++){
//	        	 Run obj = (Run) list.get(i);
//	        	 System.out.println("obj:"+obj.toString());
//	         }*/
//	         
//	         List list = doc.getTexts();
//	         for(int i=0; i<list.size(); i++){
//	        	 Text obj = (Text) list.get(i);
//	        	 System.out.println("obj:"+obj.getValue());
//	        	 
//	        	 if( obj.getValue().contains("김태훈") ){
//	        		 obj.setValue("Kim Tae Hoon");
//	        	 }
//	         }
//
//	         /*doc.replace("김태훈", "Kim Tae Hoon");
//	         doc.replace("MIDDLE NAME", "middle name");
//	         doc.replace("LAST NAME", "last name");*/
//	         
//	         
//
//	         doc.save(outpath, true);

	     } catch (Exception e) {
	         System.out.println(e.getMessage());
	         e.printStackTrace();
	     }
	}
	
	@SuppressWarnings("deprecation")
	private static void test3(String path){
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(path);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		POIFSFileSystem fileSystem = null;
		try {
			fileSystem = new POIFSFileSystem(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Firstly, get an extractor for the Workbook
		POIOLE2TextExtractor oleTextExtractor = null;
		try {
			oleTextExtractor = ExtractorFactory.createExtractor(fileSystem);
			

			   if (oleTextExtractor instanceof ExcelExtractor) {
		      ExcelExtractor excelExtractor = (ExcelExtractor) oleTextExtractor;
		      System.out.println(excelExtractor.getText());
		   }
		   // A Word Document
		   else if (oleTextExtractor instanceof WordExtractor) {
		      WordExtractor wordExtractor = (WordExtractor) oleTextExtractor;
		      String[] paragraphText = wordExtractor.getParagraphText();
		      for (String paragraph : paragraphText) {
		         System.out.println(paragraph);
		      }
		   }
		   // PowerPoint Presentation.
		   else if (oleTextExtractor instanceof PowerPointExtractor) {
		      PowerPointExtractor powerPointExtractor = (PowerPointExtractor) oleTextExtractor;
		      System.out.println("Text: " + powerPointExtractor.getText());
		      System.out.println("Notes: " + powerPointExtractor.getNotes());
		   }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (OpenXML4JException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XmlException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Then a List of extractors for any embedded Excel, Word, PowerPoint
		// or Visio objects embedded into it.
		@SuppressWarnings("deprecation")
		POITextExtractor[] embeddedExtractors = null;
		try {
			embeddedExtractors = ExtractorFactory.getEmbededDocsTextExtractors(oleTextExtractor);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (OpenXML4JException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XmlException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (POITextExtractor textExtractor : embeddedExtractors) {
		   // If the embedded object was an Excel spreadsheet.
		   if (textExtractor instanceof ExcelExtractor) {
		      ExcelExtractor excelExtractor = (ExcelExtractor) textExtractor;
		      System.out.println(excelExtractor.getText());
		   }
		   // A Word Document
		   else if (textExtractor instanceof WordExtractor) {
		      WordExtractor wordExtractor = (WordExtractor) textExtractor;
		      String[] paragraphText = wordExtractor.getParagraphText();
		      for (String paragraph : paragraphText) {
		         System.out.println(paragraph);
		      }
		   }
		   // PowerPoint Presentation.
		   else if (textExtractor instanceof PowerPointExtractor) {
		      PowerPointExtractor powerPointExtractor =
		         (PowerPointExtractor) textExtractor;
		      System.out.println("Text: " + powerPointExtractor.getText());
		      System.out.println("Notes: " + powerPointExtractor.getNotes());
		   }
		}

	}
}
