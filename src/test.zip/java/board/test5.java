package board;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.pdfbox.contentstream.operator.Operator;
import org.apache.pdfbox.cos.COSArray;
import org.apache.pdfbox.cos.COSString;
import org.apache.pdfbox.pdfparser.PDFStreamParser;
import org.apache.pdfbox.pdfwriter.ContentStreamWriter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageTree;
import org.apache.pdfbox.pdmodel.common.PDStream;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.springframework.util.StringUtils;


public class test5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String src = "E:/test.pdf";
		String dest = "E:/output.pdf";
		
		Map<String, String> map = new HashMap<>();
	    map.put("김태훈", "Kim Tae Hoon");	
	    map.put("test", "테스트");
	    
	    PDDocument document = null;
	    try {
			document = PDDocument.load(new File("E:/test.pdf"));
		} catch (InvalidPasswordException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    try {
			document = replaceText(document,map);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    try {
			document.save(dest);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static PDDocument replaceText(PDDocument document, Map<String, String> map) throws IOException {

	    PDPageTree pages = document.getDocumentCatalog().getPages();
	    for (PDPage page : pages) {
	        PDFStreamParser parser = new PDFStreamParser(page);
	        parser.parse();
	        List tokens = parser.getTokens();
	        for (int j = 0; j < tokens.size(); j++) {
	            Object next = tokens.get(j);
	            if (next instanceof Operator) {
	                Operator op = (Operator) next;
	                String pstring = "";
                    int prej = 0;
                    
	                //Tj and TJ are the two operators that display strings in a PDF
	                if (op.getName().equals("Tj")) {
	                    // Tj takes one operator and that is the string to display so lets update that operator
	                    COSString previous = (COSString) tokens.get(j - 1);
	                    String string = previous.getString();
	                    for (Map.Entry<String, String> entry : map.entrySet()) {
	                        if( string.contains(entry.getKey()) ){
	                			string = string.replace(entry.getKey(), entry.getValue());
	                		}
	                    }
	                    previous.setValue(string.getBytes());
	                } else if (op.getName().equals("TJ")) {
	                	COSArray previous = (COSArray) tokens.get(j - 1);
                        /*for (int k = 0; k < previous.size(); k++) 
                        {
                            Object arrElement = previous.getObject(k);
                            if (arrElement instanceof COSString) 
                            {
                                COSString cosString = (COSString) arrElement;
                                String string = cosString.getString();
                                
                                if (j == prej) {
                                    pstring += string;
                                } else {
                                    prej = j;
                                    pstring = string;
                                }
                            }
                        	
                        }*/
                        //System.out.println("pstring:"+previous.getString(0));
                        COSString cosString2 = (COSString) previous.getObject(0);
                        pstring = cosString2.getString();
                        for (Map.Entry<String, String> entry : map.entrySet()) {
	                        if( pstring.contains(entry.getKey()) ){
	                        	pstring = pstring.replace(entry.getKey(), entry.getValue());
	                		}
	                    }
                        System.out.println("pstring:"+pstring);
                        //pstring = "테스트";
                        cosString2.setValue(pstring.getBytes("ISO-8859-1"));
	                }
	            }
	        }
	        // now that the tokens are updated we will replace the page content stream.
	        PDStream updatedStream = new PDStream(document);
	        OutputStream out = updatedStream.createOutputStream();
	        ContentStreamWriter tokenWriter = new ContentStreamWriter(out);
	        tokenWriter.writeTokens(tokens);
	        page.setContents(updatedStream);
	        out.close();
	    }
	    return document;
	}
}
