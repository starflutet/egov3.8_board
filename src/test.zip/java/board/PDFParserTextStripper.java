package board;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.fontbox.ttf.TrueTypeCollection;
import org.apache.pdfbox.contentstream.operator.Operator;
import org.apache.pdfbox.cos.COSArray;
import org.apache.pdfbox.cos.COSString;
import org.apache.pdfbox.pdfparser.PDFStreamParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDTrueTypeFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

public class PDFParserTextStripper extends PDFTextStripper 
{
    //static StringWriter dummy = new StringWriter();
    static Writer dummy = new OutputStreamWriter(new ByteArrayOutputStream());
    //static PDDocument doc = null;
    //InputStream fontStream = new FileInputStream("E:/eGovFrameDev-3.7.0-64bit/workspace/board/src/test/java/board/NanumGothic.ttf");
    //PDType0Font fontGulim = PDType0Font.load(doc, fontStream);
    PDPageContentStream contentStream = null;
    
    public PDFParserTextStripper(PDDocument pdd) throws IOException 
    {  
        super();
        document = pdd;
    }

    public void stripPage(int pageNr) throws IOException 
    {
    	//File out = new File("E:/output.pdf");
        this.setStartPage(pageNr+1);
        this.setEndPage(pageNr+1);
        
        /*String string = this.getText(document);
        //System.out.println("string:"+string);
    	Map<String, String> map = new HashMap<>();
	    map.put("김태훈", "Kim Tae Hoon");	    
    	for (Map.Entry<String, String> entry : map.entrySet()) {
            if (entry.getKey().equals(string)) {
            	string = entry.getValue();
            }
    		if( string.contains(entry.getKey()) ){
    			string = string.replace(entry.getKey(), entry.getValue());
    		}
        }
        //System.out.println("string2:"+string);
    	this.writeString(string);*/
        
        PDPage page = document.getPage(pageNr);       
        contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND,true,true);
        contentStream.beginText();
        contentStream.setFont( PDType1Font.TIMES_ROMAN, 10 );
        //contentStream.newLineAtOffset(25, 725 );
        
        writeText(document,dummy); // This call starts the parsing process and calls writeString repeatedly.
        
        contentStream.endText();
        contentStream.close();
    }
    
    @Override
    protected void writeString(String string) throws IOException 
    {
    	//System.out.println("string:"+string);    	
    	
    	//this.beginText();
    	//this.output.write(string);
    	/*PDPageContentStream contentStream = new PDPageContentStream(document, this.getCurrentPage(), PDPageContentStream.AppendMode.APPEND,true,true);
    	contentStream.setFont(pdfFont, fontSize)
    	contentStream.beginText()
    	contentStream.lineTo(200,685)
    	contentStream.showText("John")
    	contentStream.endText()
    	this.showTextString(string.getBytes());*/
    	//this.endText();
    }

    @Override
    protected void writeString(String string,List<TextPosition> textPositions) throws IOException 
    {    	
        
        Map<String, String> map = new HashMap<>();
	    map.put("김태훈", "Kim Tae Hoon");	    
    	for (Map.Entry<String, String> entry : map.entrySet()) {
            if( string.contains(entry.getKey()) ){
    			string = string.replace(entry.getKey(), entry.getValue());
    		}
        }
        //PDPageContentStream contentStream = new PDPageContentStream(doc, doc.getPage(1), PDPageContentStream.AppendMode.APPEND,true,true);
        //contentStream.beginText();
        //contentStream.setFont(fontGulim, 10);
    	
        for (TextPosition text : textPositions) {
            System.out.println("String[" + text.getXDirAdj()+","+text.getYDirAdj()+" fs="+text.getFontSizeInPt()+" xscale="+text.getXScale()+" height="+text.getHeightDir()+" space="+text.getWidthOfSpace()+" width="+text.getWidthDirAdj()+" ] "+text.getUnicode());
            contentStream.moveTo(text.getXDirAdj(), text.getYDirAdj());
            contentStream.showText(string);
        }
        
        //contentStream.endText();
        //contentStream.close();
        
        writeString(string);
        
    }

    public static void extractText(InputStream inputStream)
    {
        PDDocument pdd = null;

        try 
        {
        	//doc = new PDDocument();
            pdd = PDDocument.load(inputStream);
            
            /*for(PDPage page : pdd.getPages()){
            	doc.addPage(page);
            }*/
            	
            PDFParserTextStripper stripper = new PDFParserTextStripper(pdd);
            stripper.setSortByPosition(true);
            for (int i=0; i<pdd.getNumberOfPages(); i++)
            {
                stripper.stripPage(i);
            }
            
            File out = new File("E:/output.pdf");
    	    try {
    	    	//doc = PDDocument.load(out);
    	    	//System.out.println(dummy);
    	    	//PDDocument doc = null;
    	         try
    	         {
    	             //doc = new PDDocument();
    	             /*InputStream fontStream = new FileInputStream("E:/eGovFrameDev-3.7.0-64bit/workspace/board/src/test/java/board/NanumGothic.ttf");
    	             PDType0Font fontGulim = PDType0Font.load(doc, fontStream);*/
    	             //File fontFile = new File("C:/Windows/fonts/gulim.ttc");
    	             //PDType0Font fontGulim = PDType0Font.load(doc, new TrueTypeCollection(fontFile).getFontByName("굴림"), true);

    	             //for(PDPage page : pdd.getPages()){
    	            	 //PDPageContentStream stream = page.getc
    	            	 /*Iterator itr = page.getContentStreams();
    	            	 while(itr.hasNext()){
    	            		 PDPageContentStream stream = (PDPageContentStream) itr.next();
    	            		 stream.showText(dummy.toString());
    	            	 }*/
    	            //	 doc.addPage(page);
    	             //}
    	             //PDPage page = new PDPage();
    	             //doc.addPage(page);

    	             /*PDPageContentStream contentStream = new PDPageContentStream(doc,page);
    	             contentStream.beginText();
    	             contentStream.setFont(fontGulim, 10);
    	             contentStream.moveTo(x, y);
    	             contentStream.showText(dummy.toString());
    	             contentStream.endText();
    	             contentStream.close();*/
    	             //doc.save(out);
    	        	 pdd.save(out);
    	         }
    	         finally
    	         {
    	             /*if (doc != null)
    	             {
    	                 doc.close();
    	             }*/
    	         }
    	    	
    	    	
    	    	//pdd.save(out);
    	    	//doc.close();
    		} catch (IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
        } 
        catch (IOException e) 
        {
            // throw error
        } 
        finally 
        {
            if (pdd != null) 
            {
                try 
                {
                    pdd.close();
                } 
                catch (IOException e) 
                {

                }
            }
        }
    }

    public static void main(String[] args) throws IOException
    {
        File f = new File("E:/input.pdf");
        FileInputStream fis = null;

        try 
        {
            fis = new FileInputStream(f);
            extractText(fis);
        } 
        catch(IOException e) 
        {
            e.printStackTrace();
        } 
        finally 
        {
            try 
            {
                if(fis != null)
                    fis.close();
            } 
            catch(IOException ex)
            {
                ex.printStackTrace();
            }
        }
    }

}
