package board;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Document;

public class test7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test();
	}

	public static void test(){
		Map<String, String> map = new HashMap<>();
	    map.put("김태훈", "Kim Tae Hoon");	
	    map.put("test", "테스트");
	    map.put("Website", "웹사이트");
		//String src = "E:/output.html";
		//String dest = "E:/output.pdf";
		String src = "E:/test_out.html";
		String dest = "E:/test_out.pdf";
		
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(src);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String line = "";
		String result = "";
		String mode = "english";
		BufferedReader rd = null;
		try {
			rd = new BufferedReader(new InputStreamReader(fis,"utf-8"));
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			for (Map.Entry<String, String> entry : map.entrySet()) {
				if(entry.getValue().matches(".*[ㄱ-ㅎㅏ-ㅣ가-힣]+.*")) {
					mode = "korean";
					break;
				}
			}
			while ((line = rd.readLine()) != null) {
				//System.out.println(line);
				if( line.contains("font-size") ){
					//line = line.replace("font-size", "user-font-size");
					//line = line.replace("width", "user-width");
					String text = line.substring(line.indexOf("font-size"),line.length());
					text = text.substring(0, text.indexOf(";"));
					
					String[] imsi = text.split(":");
					String txt = imsi[1].trim();
					//txt = imsi[0]+":"+txt.substring(0, txt.indexOf(".")-1)+"pt";
					txt  = imsi[0]+":8pt";
					line = line.replace(text, txt);
					
					//line = line.replace("INPILL DotumChe", "NanumGothic");
					//line = line.replace("INPILL GulimChe", "NanumGothic");
					

					if( line.contains("width") ){
						text = line.substring(line.indexOf("width"),line.length());
						text = text.substring(0, text.indexOf(";"));
						imsi = text.split(":");
						txt = imsi[1].trim();
						//System.out.println("txt:"+txt);
						//System.out.println("txt2:"+txt.substring(0, txt.indexOf(".")));
						if( txt.indexOf(".") >= 0 ){
							txt = imsi[0]+":"+Integer.parseInt(txt.substring(0, txt.indexOf(".")))*2+"pt";
						}else{
							txt = imsi[0]+":"+Integer.parseInt(txt.substring(0, txt.indexOf("pt")))*2+"pt";
						}
						line = line.replace(text, txt);
					}
				}
				if( line.contains("font-family") ){
					String text = line.substring(line.indexOf("font-family"),line.length());
					text = text.substring(0, text.indexOf(";"));
					
					String[] imsi = text.split(":");
					String txt = imsi[1].trim();
					txt = imsi[0]+":"+"NanumGothic";
					//txt = imsi[0]+":"+"malgun";
					//txt = imsi[0]+":"+"NanumMyeongjo";
					//txt = imsi[0]+":"+"HANBatang";
					
					if(line.matches(".*[ㄱ-ㅎㅏ-ㅣ가-힣]+.*")) {
						line = line.replace(text, txt);
					}
					
					for (Map.Entry<String, String> entry : map.entrySet()) {
	                    if( line.contains(entry.getKey()) ){	                    	
	                    	if( "korean".equals(mode) ){
		                    	line = line.replace(text, txt);
	                    	}
	            		}
	                }
					
					//line = line.replace("width", "user-width");
				}
				if( line.contains("data:image") ){
					String text = "style=\"";
					String txt = "style=\"display:none;";
					line = line.replace(text, txt);
				}
				/*if( line.contains("class=\"r\"") && line.contains("background-color:#000000;") ){
					String text = "background-color:#000000;";
					String txt = "";
					line = line.replace(text, txt);
				}*/
				for (Map.Entry<String, String> entry : map.entrySet()) {
                    if( line.contains(entry.getKey()) ){
                    	line = line.replace(entry.getKey(), entry.getValue());
            		}
                }
				result += line; 
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//result = result.replace("font-size", "user-font-size");
		//result = result.replace("width", "user-width");
		
		OutputStreamWriter fw = null;
		try {
			fw = new OutputStreamWriter(new FileOutputStream(src));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fw.write(result);
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Document doc = Jsoup.parse(result);
		//String doc.body().toString();
	}
	
	public static String test2(String output){
		Map<String, String> map = new HashMap<>();
	    map.put("김태훈", "Kim Tae Hoon");	
	    map.put("test", "테스트");
	    map.put("Website", "웹사이트");
		//String src = "E:/output.html";
		//String dest = "E:/output.pdf";
		//String src = "E:/test_out.html";
		//String dest = "E:/test_out.pdf";
		
		String line = "";
		String result = "";
		String mode = "english";
		BufferedReader rd = null;
		try {
			rd = new BufferedReader(new StringReader(output));
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			for (Map.Entry<String, String> entry : map.entrySet()) {
				if(entry.getValue().matches(".*[ㄱ-ㅎㅏ-ㅣ가-힣]+.*")) {
					mode = "korean";
					break;
				}
			}
			while ((line = rd.readLine()) != null) {
				//System.out.println(line);
				if( line.contains("font-size") ){
					//line = line.replace("font-size", "user-font-size");
					//line = line.replace("width", "user-width");
					String text = line.substring(line.indexOf("font-size"),line.length());
					text = text.substring(0, text.indexOf(";"));
					
					String[] imsi = text.split(":");
					String txt = imsi[1].trim();
					//txt = imsi[0]+":"+txt.substring(0, txt.indexOf(".")-1)+"pt";
					txt  = imsi[0]+":8pt";
					line = line.replace(text, txt);
					
					//line = line.replace("INPILL DotumChe", "NanumGothic");
					//line = line.replace("INPILL GulimChe", "NanumGothic");
					
					
					if( line.contains("width") ){
						text = line.substring(line.indexOf("width"),line.length());
						text = text.substring(0, text.indexOf(";"));
						imsi = text.split(":");
						txt = imsi[1].trim();
						//System.out.println("txt:"+txt);
						if( txt.indexOf(".") >= 0 ){
							txt = imsi[0]+":"+Integer.parseInt(txt.substring(0, txt.indexOf(".")))*2+"pt";
						}else{
							txt = imsi[0]+":"+Integer.parseInt(txt.substring(0, txt.indexOf("pt")))*2+"pt";
						}
						line = line.replace(text, txt);
					}
				}
				if( line.contains("font-family") ){
					String text = line.substring(line.indexOf("font-family"),line.length());
					text = text.substring(0, text.indexOf(";"));
					
					String[] imsi = text.split(":");
					String txt = imsi[1].trim();
					txt = imsi[0]+":"+"NanumGothic";
					//txt = imsi[0]+":"+"malgun";
					//txt = imsi[0]+":"+"NanumMyeongjo";
					//txt = imsi[0]+":"+"HANBatang";
					
					if(line.matches(".*[ㄱ-ㅎㅏ-ㅣ가-힣]+.*")) {
						line = line.replace(text, txt);
					}
					
					for (Map.Entry<String, String> entry : map.entrySet()) {
	                    if( line.contains(entry.getKey()) ){	                    	
	                    	if( "korean".equals(mode) ){
		                    	line = line.replace(text, txt);
	                    	}
	            		}
	                }
					
					//line = line.replace("width", "user-width");
				}
				if( line.contains("data:image") ){
					String text = "style=\"";
					String txt = "style=\"display:none;";
					line = line.replace(text, txt);
				}
				/*if( line.contains("class=\"r\"") && line.contains("background-color:#000000;") ){
					String text = "background-color:#000000;";
					String txt = "";
					line = line.replace(text, txt);
				}*/
				for (Map.Entry<String, String> entry : map.entrySet()) {
                    if( line.contains(entry.getKey()) ){
                    	line = line.replace(entry.getKey(), entry.getValue());
            		}
                }
				result += line; 
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
}
