package board;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.fit.pdfdom.PDFDomTree;
import org.w3c.dom.Document;

public class test6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		test();
		test2();
		System.out.println("=====complete=====");
	}

	public static void test() {
		String src = "E:/input.pdf";
		String dest = "E:/output.pdf";
		//String src = "E:/test2.pdf";
		//String dest = "E:/test_out.pdf";
		String html = "E:/test_out.html";
		
		Map<String, String> map = new HashMap<>();
	    map.put("김태훈", "Kim Tae Hoon");	
	    map.put("test", "테스트");
	    
		PDDocument pdf = null;
		try {
			pdf = PDDocument.load(new File(src));
		} catch (InvalidPasswordException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Writer output = null;
		//PDFDomTreeConfig config = PDFDomTreeConfig.createDefaultConfig();
		//PDFDomTreeConfig.ignoreResource();
		try {
			output = new PrintWriter(html, "utf-8");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			//new PDFDomTree().writeText(pdf, output);
			PDFDomTree parser = new PDFDomTree();
			//dom = parser.createDOM(pdf);
			parser.writeText(pdf, output);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
			output.close();
			pdf.close();
			
			test7.test();
			test8.test();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void test2() {
		//String src = "E:/input.pdf";
		//String dest = "E:/output.pdf";
		String src = "E:/test2.pdf";
		String dest = "E:/test_out2.pdf";
		
		Map<String, String> map = new HashMap<>();
	    map.put("김태훈", "Kim Tae Hoon");	
	    map.put("test", "테스트");
	    
		PDDocument pdf = null;
		try {
			pdf = PDDocument.load(new File(src));
		} catch (InvalidPasswordException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Writer output = null;
		Document dom = null;
		String result = "";
		PrintStream old = System.out;
		java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();    
		System.setOut(new java.io.PrintStream(out));
		//PDFDomTreeConfig config = PDFDomTreeConfig.createDefaultConfig();
		//PDFDomTreeConfig.ignoreResource();
		try {
			output = new BufferedWriter(new OutputStreamWriter(out));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			//new PDFDomTree().writeText(pdf, output);
			PDFDomTree parser = new PDFDomTree();
			//dom = parser.createDOM(pdf);
			parser.writeText(pdf, output);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
        	out.close();
			output.close();
			pdf.close();
			
			
			System.setOut(old);
			result = out.toString("utf-8");
			//System.out.println("aaaaa===="+result);
			result = test7.test2(result);
			//System.out.println("bbbbb===="+result);
			test8.test2(result.getBytes());
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
