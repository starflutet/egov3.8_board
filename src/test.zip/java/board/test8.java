package board;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.MalformedURLException;

import org.apache.pdfbox.pdmodel.font.PDFontFactory;
import org.apache.pdfbox.pdmodel.font.PDTrueTypeFont;
import org.xhtmlrenderer.pdf.ITextFontResolver;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.BaseFont;

public class test8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test();
	}
	
	public static void test(){
		//String src = "E:/output.html";
		//String dest = "E:/output.pdf";
		String src = "E:/test_out.html";
		String dest = "E:/test_out.pdf";
		
		String url = null;
		try {
			url = new File(src).toURI().toURL().toString();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.println("URL: " + url);

        OutputStream out = null;
		try {
			out = new FileOutputStream(dest);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        //Flying Saucer part
        ITextRenderer renderer = new ITextRenderer();
        ITextFontResolver ifr =  renderer.getFontResolver(); // 한글로 나오게 할려면 필요하다
        try {
        	//ifr.addFont("E:/eGovFrameDev-3.7.0-64bit/workspace/board/src/test/java/board/arial.ttf", BaseFont.IDENTITY_H, true);
			//ifr.addFont("E:/eGovFrameDev-3.7.0-64bit/workspace/board/src/test/java/board/NanumGothic.ttf", BaseFont.IDENTITY_H, true);
        	//ifr.addFont(test8.class.getResource("arial.ttf").toString(), BaseFont.IDENTITY_H, true);
			//ifr.addFont(test8.class.getResource("malgun.ttf").toString(), BaseFont.IDENTITY_H, true);
			ifr.addFont(test8.class.getResource("NanumGothic.ttf").toString(), BaseFont.IDENTITY_H, true);
			//ifr.addFont(test8.class.getResource("NanumMyeongjo.ttf").toString(), BaseFont.IDENTITY_H, true);
			//ifr.addFont(test8.class.getResource("HANBatang.ttf").toString(), BaseFont.IDENTITY_H, true);
		} catch (DocumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        renderer.setDocument(url);
        renderer.layout();
        renderer.setScaleToFit(true);
        try {
			renderer.createPDF(out);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        try {
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void test2(byte[] bytes){
		//String src = "E:/output.html";
		//String dest = "E:/output.pdf";
		//String src = "E:/test_out.html";
		String dest = "E:/test_out2.pdf";

        OutputStream out = null;
		try {
			out = new FileOutputStream(dest);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        //Flying Saucer part
        ITextRenderer renderer = new ITextRenderer();
        ITextFontResolver ifr =  renderer.getFontResolver(); // 한글로 나오게 할려면 필요하다
        try {
        	//ifr.addFont("E:/eGovFrameDev-3.7.0-64bit/workspace/board/src/test/java/board/arial.ttf", BaseFont.IDENTITY_H, true);
			//ifr.addFont("E:/eGovFrameDev-3.7.0-64bit/workspace/board/src/test/java/board/NanumGothic.ttf", BaseFont.IDENTITY_H, true);
        	//ifr.addFont(test8.class.getResource("arial.ttf").toString(), BaseFont.IDENTITY_H, true);
			//ifr.addFont(test8.class.getResource("malgun.ttf").toString(), BaseFont.IDENTITY_H, true);
			ifr.addFont(test8.class.getResource("NanumGothic.ttf").toString(), BaseFont.IDENTITY_H, true);
			//ifr.addFont(test8.class.getResource("NanumMyeongjo.ttf").toString(), BaseFont.IDENTITY_H, true);
			//ifr.addFont(test8.class.getResource("HANBatang.ttf").toString(), BaseFont.IDENTITY_H, true);
		} catch (DocumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        try {
			renderer.setDocument(bytes);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        renderer.layout();
        renderer.setScaleToFit(true);
        try {
			renderer.createPDF(out);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        try {
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
